<?php include 'includes/header.php'; ?>
<div class="container mt-5">
  <h2>Our Services</h2>
  <ul>
    <li>Web Development</li>
    <li>Mobile App Development</li>
    <li>Digital Marketing</li>
  </ul>
</div>
<?php include 'includes/footer.php'; ?>