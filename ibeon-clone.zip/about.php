<?php include 'includes/header.php'; ?>
<div class="container mt-5">
  <h2>About Us</h2>
  <p>We are a passionate team offering IT services to transform businesses.</p>
</div>
<?php include 'includes/footer.php'; ?>