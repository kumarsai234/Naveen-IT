<footer class="bg-dark text-white text-center p-3 mt-5">
  &copy; <?= date("Y") ?> IBEON Clone. All rights reserved.
</footer>
<script src="assets/js/bootstrap.bundle.min.js"></script>
</body>
</html>