<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Ibeon Clone</title>
  <link href="assets/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="index.php">IBEON</a>
  <div class="collapse navbar-collapse">
    <ul class="navbar-nav ms-auto">
      <li><a class="nav-link" href="index.php">Home</a></li>
      <li><a class="nav-link" href="about.php">About</a></li>
      <li><a class="nav-link" href="services.php">Services</a></li>
      <li><a class="nav-link" href="contact.php">Contact</a></li>
    </ul>
  </div>
</nav>