<?php include 'includes/header.php'; ?>
<div class="container text-center mt-5">
  <h1>Welcome to IBEON Clone</h1>
  <p>We provide innovative IT solutions</p>
</div>
<?php include 'includes/footer.php'; ?>